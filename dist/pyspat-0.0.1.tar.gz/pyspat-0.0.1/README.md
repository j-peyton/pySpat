Work in progress project for spatial statistical methods under one python based roof.
